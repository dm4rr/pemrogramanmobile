package com.damar.mydutyactivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SecondActivity extends AppCompatActivity {
     public static final String TEMP_NAMA = "temp_nama";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;


        });
        TextView tvShowNama = findViewById(R.id.tc_showNama);
        EditText etphone = findViewById(R.id.et_phone);
        Button btDialUp = findViewById(R.id.bt_dialUp);

        String nama = getIntent().getStringExtra(TEMP_NAMA);
        String text = "Nama Anda:" +nama;
        tvShowNama.setText(text);

        btDialUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Nomor = etphone.getText().toString().trim();
                Intent intenTelp= new Intent(Intent.ACTION_DIAL, Uri.parse("damartel:"+Nomor));
                startActivity(intenTelp);
            }
        });
    }
}