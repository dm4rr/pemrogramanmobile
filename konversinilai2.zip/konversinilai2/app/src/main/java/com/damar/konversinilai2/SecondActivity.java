package com.damar.konversinilai2;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    private TextView textViewHasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textViewHasil = findViewById(R.id.textViewHasil);

        int nilai = getIntent().getIntExtra("NILAI_ANGKA", -1);
        String nilaiHuruf = konversiNilai(nilai);

        textViewHasil.setText("Nilai Anda: " + nilai + "\nKonversi: " + nilaiHuruf);
    }

    private String konversiNilai(int nilai) {
        if (nilai >= 80 && nilai <= 100) return "A";
        else if (nilai >= 70) return "B";
        else if (nilai >= 60) return "C";
        else if (nilai >= 50) return "D";
        else if (nilai >= 0) return "E";
        else return "Nilai tidak valid";
    }
}