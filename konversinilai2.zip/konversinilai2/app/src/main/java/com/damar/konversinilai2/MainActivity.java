package com.damar.konversinilai2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNumber;
    private Button buttonLanjut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNumber = findViewById(R.id.editTextNumber);
        buttonLanjut = findViewById(R.id.buttonLanjut);

        buttonLanjut.setOnClickListener(v -> {
            String input = editTextNumber.getText().toString().trim();

            if (input.isEmpty()) {
                Toast.makeText(this, "Masukkan nilai terlebih dahulu.", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int nilai = Integer.parseInt(input);
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("NILAI_ANGKA", nilai);
                startActivity(intent);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Input harus berupa angka.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}